
<?php $__env->startSection('content'); ?> 
<div class="page-wrapper">
      <div class="content container-fluid">
      
        <!-- Page Header -->
          <div class="page-header">
            <div class="row">
              <div class="col">
                <h3 class="page-title"><i class="<?php echo e($icon); ?>" style="color: #518c68"></i> <?php echo e(isset($data)?'Update':'Add'); ?> Team</h3></h3>
              </div>
            </div>
          </div>
          <!-- /Page Header -->
          
          <div class="row">
            
            <div class="col-lg-12 col-md-12">
              <div class="card">
                <div class="card-body">
                  <?php if(session()->has('success')): ?>
                      <div class="alert alert-success alert-dismissible fade show">
                          <?php echo e(session()->get('success')); ?>

                      </div>
                  <?php endif; ?>

                  <?php if(session()->has('error')): ?>
                      <div class="alert alert-danger alert-dismissible fade show">
                          <?php echo e(session()->get('error')); ?>

                      </div>
                  <?php endif; ?>

                  <form method="post" action="<?php echo e(isset($data)?route('team.update', [$data->id]):route('team.store')); ?>">
                    <?php echo csrf_field(); ?>

                     <div class="form-group">
                      <label for="">Region</label>
                      <select name="region" id="" class="form-control">
                        <option value="">Select Region</option>
                      <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>" <?php echo e(isset($data) && $data->region_id==$value->id?'selected':''); ?> ><?php echo e(strtoupper($value->region_name)); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                      <label for="">Team Name</label>
                      <input type="text" name="team" placeholder="Team Name" value="<?php echo e($data->team_name??''); ?>" class="form-control">
                      <?php $__errorArgs = ['team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  

                    <a href="<?php echo e(route('teams.index')); ?>"><button type="button" class="btn btn-danger"> < Back</button></a>

                    <input type="submit" value="<?php echo e(isset($data)?'Update':'Add'); ?> Team" class="btn btn-<?php echo e(isset($data)?'success':'primary'); ?>">
                  </form>
                </div>
              </div>
            </div>
          </div>
        
        </div>      
      </div>
      <!-- /Main Wrapper -->
  </div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pubglite/public_html/test/resources/views/teams/create.blade.php ENDPATH**/ ?>