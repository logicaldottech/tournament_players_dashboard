
<?php $__env->startSection('content'); ?>	

<div class="page-wrapper">
			<div class="content container-fluid">
			
				<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col">
								<h3 class="page-title"><i class="<?php echo e($icon); ?>" aria-hidden="true"></i> Activities</h3>
								
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						
						<div class="col-lg-12 col-md-12">
							<div class="card">
								<div class="card-body">
									
									<form method="get" action="<?php echo e(route('activities.index')); ?>">
										<?php echo csrf_field(); ?>

									<div class="row">
															
				                        <div class="form-group col-3">
			                                <label for="">Activity Type</label>
			                                <select name="activity_type" id="activity_type" class="form-control" >
			                                  <option value="">Select Type</option>
			                                <?php $__currentLoopData = $activity_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                  <option value="<?php echo e($value->id); ?>" <?php echo e(isset($activity_type) && $activity_type == $value->id ? "selected": ""); ?>><?php echo e(ucfirst($value->name)); ?></option>
			                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                              </div>

			                              <div class="form-group col-3">
			                                <label for="">Team</label>
			                                <select name="team_id" id="team_id" class="form-control" >
			                                  <option value="<?php echo e($team->id); ?>"><?php echo e($team->team_name); ?></option>
			                                  <option value="all">All Teams</option>
			                                </select>
			                              </div>

			                              <div class="form-group col-3 col-md-3">
										  	<label class="text-white" for="">Start Date</label>
										    <input type="date" name="start_date" value="<?php echo e($start_date??''); ?>" class="form-control mr-3" id="" placeholder="Start Date">
										  </div>

										<div class="form-group col-3 col-md-3">
										  	<label class="text-white" for="">End Date</label>
										    <input type="date" name="end_date" value="<?php echo e($end_date??''); ?>" class="form-control mr-3" id="" placeholder="End Date">
										</div>
				                    <!-- </div>
				                    <div class="row"> -->
									  <div class="form-group col-3 col-md-3">
									  	<label class="text-white" for="">Search</label>
									    <input type="text" name="search" value="<?php echo e($search??''); ?>" class="form-control mr-3" id="" placeholder="search">
										</div>
										<div class="form-group col-1 col-md-1" style="margin-top: 2rem!important;">
									   	<button type="submit" class="btn btn-primary">Search</button>
										</div>

										<div class="form-group col-2 col-md-2" style="margin-top: 2rem!important;">
											<a href="<?php echo e(route('activities.index')); ?>">
									   			<button type="button" class="btn btn-danger">Reset Filter</button>
									   		</a>
										</div>
									
									  </div>
									</div>
									</form>
								<div class="row mt-3">
									<div class="col-md-3 offset-md-9">
								  		<a href="<?php echo e(route('activity.create')); ?>"><button class="btn btn-success mb-3 float-right">Add Activity <i class="fas fa-plus-circle"></i> </button></a>
								  	</div>
								</div>
								  <?php if(session()->has('success')): ?>
									    <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
									<?php endif; ?>

									<?php if(session()->has('error')): ?>
									    <span class="invalid-feedback" role="alert">
				                          <strong><?php echo e($message); ?></strong>
				                      </span>
									<?php endif; ?>
				                  <table id="" class="display table dataTable table-striped table-bordered" >
				                     <thead>
				                        <tr>
				                           <th>#</th>
				                           <th>Activity Name</th>
				                           <th>Team Name</th>
				                           <th>Start Activity</th>
				                           <th>Meeting place</th>
				                           <th>Max Participants</th>
				                           <th>Register Start Date</th>
				                           <th>Register End Date</th>
				                           <th>Created At</th>
				                           <th>Action</th>
				                        </tr>
				                     </thead>
				                     <tbody>
				                     	<?php if(count($data) > 0): ?>
				                     	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				                     	<tr>
				                     		<td><?php echo e($data->firstItem() + $key); ?></td>
				                     		<td><?php echo e($value->title); ?> <font style="font-size:10px"> <br/>Activity Type: <?php echo e($value->activityType->name??'NA'); ?></font></td>
				                     		<td><?php echo e($value->team->team_name); ?></td>
				                     		<td>Start Date: <b><?php echo e($value->start_date); ?> </b><br /><font style="font-size:10px">End Date: <?php echo e($value->end_date??'NA'); ?></font></td>
				                     		<td><?php echo e($value->meeting_place); ?><br /><font style="font-size:10px">Time: <?php echo e($value->meeting_time??'NA'); ?></font></td>
				                     		<td><?php echo e($value->max_participants); ?></td>
				                     		<td><?php echo e($value->register_start_date??'NA'); ?></td>
				                     		<td><?php echo e($value->register_end_date); ?></td>
				                     		<td><?php echo e(date('d M Y', strtotime($value->fld_created_at) )); ?></td>
				                     		<td>
					                            <a href="<?php echo e(route('activity.show', $value->id)); ?>" class="btn btn-info" >
					                              <i class="fas fa-eye"></i>
					                            </a>

					                            <a onclick="return confirm('Are you sure you want to delete?');" href="<?php echo e(route('activity.destroy', $value->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
				                     		</td>
				                     	</tr>
				                     	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                     	<?php else: ?>
			                                <tr>
			                                    <td colspan="10">No Activity Found</td>
			                                </tr>
			                            <?php endif; ?>
			                            </tbody>
			                            <tfoot>
				                           <tr>
				                                <th>#</th>
					                           <th>Activity Name</th>
					                           <th>Team Name</th>
					                           <th>Start Activity</th>
					                           <th>Meeting place</th>
					                           <th>Max Participants</th>
					                           <th>Register Start Date</th>
					                           <th>Register End Date</th>
					                           <th>Created At</th>
					                           <th>Action</th>
				                           </tr>
				                        </tfoot>
			                        </table>
			                        
			                        <?php echo e($data->appends(request()->except('page'))->links()); ?>

								</div>
							</div>
						</div>
					</div>
				
				</div>			
			</div>
			<!-- /Main Wrapper -->
	</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/activities/index.blade.php ENDPATH**/ ?>