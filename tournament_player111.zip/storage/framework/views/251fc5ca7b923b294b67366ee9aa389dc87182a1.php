<!-- modal start for add payment -->
<div class="modal" id="importUsers">
   <div class="modal-dialog">
      <div class="modal-content">
         <!-- Modal Header -->
         <div class="modal-header">
            <h4 class="modal-title"> Import Users </h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
         </div>
         <!-- Modal body -->
         <div class="modal-body">
            <form id="form_validation" enctype="multipart/form-data" action="<?php echo e(route('users.import')); ?>" method="POST">
            	<?php echo csrf_field(); ?>
                  <input type="file" name="users_csv" required="required">
                  <a href="<?php echo e(asset('assets/csv/users-sample.csv')); ?>">Sample CSV</a>
                  <button type="submit" name="submit" class="btn btn-primary" style="margin-left: 188px;margin-top:14px";><i class="fas fa-file-excel"></i> Import</button>
            </form>
            </div>
         </div>
      </div>
      <div class="modal-footer"> </div>
   </div>
</div>
<!-- modal end for add payment --><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/modals/import_users.blade.php ENDPATH**/ ?>