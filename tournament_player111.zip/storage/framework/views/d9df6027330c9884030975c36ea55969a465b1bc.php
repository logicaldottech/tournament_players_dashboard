
<?php $__env->startSection('content'); ?> 
<div class="page-wrapper">
      <div class="content container-fluid">
      
        <!-- Page Header -->
          <div class="page-header">
            <div class="row">
              <div class="col">
                <h3 class="page-title"><i class="<?php echo e($icon); ?>" style="color: #518c68"></i> Send Email</h3></h3>
              </div>
            </div>
          </div>
          <!-- /Page Header -->
          
          <div class="row">
            
            <div class="col-lg-12 col-md-12">
              <div class="card">
                <div class="card-body">
                  <?php if(session()->has('success')): ?>
                      <div class="alert alert-success alert-dismissible fade show">
                          <?php echo e(session()->get('success')); ?>

                      </div>
                  <?php endif; ?>

                  <?php if(session()->has('error')): ?>
                      <div class="alert alert-danger alert-dismissible fade show">
                          <?php echo e(session()->get('error')); ?>

                      </div>
                  <?php endif; ?>

                  <form method="post" action="<?php echo e(route('email.send')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group col-6">
					  	<label style="width: 100%;" for="">Email Send Type</label>
						  <div class="form-check form-check-inline">
							  <input name="email_send_type" class="form-check-input email_Send" type="radio" id="all_email" value="all">
							  <label class="form-check-label" for="all">Send Email to all users</label>
							</div>

							<div class="form-check form-check-inline">
							  <input name="email_send_type" class="form-check-input email_Send" type="radio" id="team_email" value="team_email" checked>
							  <label class="form-check-label" for="team_email">Send to specific team</label>
							</div>

						</div>

                     <div class="form-group col-6 team_section">
                      <label for="">Team</label>
                      <select name="team" id="" class="form-control">
                        <option value="">Select Team</option>
                      <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>" ><?php echo e(strtoupper($value->team_name)); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php $__errorArgs = ['team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 

                    <div class="form-group col-6">
					    <label for="">Subject</label>
					    <input type="text" name="subject" placeholder="Email Subject" class="form-control" required>
					    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="alert alert-danger"><?php echo e($message); ?></div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					  </div>

					  <div class="form-group col-6">
					    <label for="">Message</label>
					    <textarea name="message" placeholder="Email Message" class="form-control" required></textarea>
					    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="alert alert-danger"><?php echo e($message); ?></div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					  </div>



                    <a href="<?php echo e(route('teams.index')); ?>"><button type="button" class="btn btn-danger"> < Back</button></a>

                    <input type="submit" value="Send Email" class="btn btn-<?php echo e(isset($data)?'success':'primary'); ?>">
                  </form>
                </div>
              </div>
            </div>
          </div>
        
        </div>      
      </div>
      <!-- /Main Wrapper -->
  </div>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("form").validate();
		$('.email_Send').click(function() {
			   var radioValue = $("input[name='email_send_type']:checked").val();
	            if(radioValue === 'all'){
	                $('.team_section').hide();
	            }else{
	            	$('.team_section').show();
	            }
			});
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pubglite/public_html/test/resources/views/send_emails/index.blade.php ENDPATH**/ ?>