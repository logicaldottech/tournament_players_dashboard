
<?php $__env->startSection('content'); ?>	

<div class="page-wrapper">
			<div class="content container-fluid">
			
				<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col">
								<h3 class="page-title"><i class="<?php echo e($icon); ?>" aria-hidden="true"></i> Activities</h3>
								
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						
						<div class="col-lg-12 col-md-12">
							<div class="card">
								<div class="card-body">
									
									
								  <?php if(session()->has('success')): ?>
									    <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
									<?php endif; ?>

									<?php if(session()->has('error')): ?>
									    <span class="invalid-feedback" role="alert">
				                          <strong><?php echo e($message); ?></strong>
				                      </span>
									<?php endif; ?>

									<div class="row mt-3">
										<div class="col-md-3">
									  		<a href="<?php echo e(route('activities.index')); ?>"><button class="btn btn-info mb-3 float-left">Back </button></a>
									  	</div>
									</div>
				                  
				                  <div class="row">
				                  	<div class="col-6" style="padding: 10px;">
				                  		<div class="card bg-light mb-3">
										  <div class="card-header">Details</div>
										  <div class="card-body">
										  	<div class="row">
											    <div class="col-6">
											    	<span class="text-grey">Created By</span>
											    	<span class="text-grey"><?php echo e($data->user->first_name . " " .$data->user->last_name); ?></span>
											    </div>
											    <div class="col-6">
											    	<?php if($ownerStatus === false): ?>
											    	<a href="<?php echo e(route('activity.attending', $data->id)); ?>"><button class="btn btn-success">Attend</button></a>
											    	<a href="<?php echo e(route('activity.not-attending', $data->id)); ?>"><button class="btn btn-warning">Not Attending</button></a>
											    	<?php elseif($ownerStatus === 'attending'): ?>
											    	<span class="text-black">You are available</span>
											    	<a href="<?php echo e(route('activity.not-attending', $data->id)); ?>"><button class="btn btn-warning">Not Attending</button></a>
											    	<?php elseif($ownerStatus === 'not-attending'): ?>
											    	<span class="text-black">You are Not available</span>
											    	<a href="<?php echo e(route('activity.attending', $data->id)); ?>"><button class="btn btn-success">Attend</button></a>
											    	<?php endif; ?>

											    </div>
											</div>

											<div class="row">
											    <div class="col-6">
											    	<span class="text-grey">Activity Title</span> <br/>
											    	<span class="text-black"><?php echo e($data->activityType->name); ?></span>
											    </div>
											    <div class="col-6">
											    	<span class="text-grey">Activity Type</span> <br/>
											    	<span class="text-black"><?php echo e($data->title); ?></span>
											    </div>
											</div>

											<div class="row">
											    <div class="col-6">
											    	<span class="text-grey">Start Date</span> <br/>
											    	<span class="text-black"><?php echo e($data->start_date); ?></span>
											    </div>
											    <div class="col-6">
											    	<span class="text-grey">Start Time</span> <br/>
											    	<span class="text-black"><?php echo e($data->starting_time); ?></span>
											    </div>
											</div>

											<div class="row">
											    <div class="col-6">
											    	<span class="text-grey">End Date</span> <br/>
											    	<?php if($data->activity_end_another_date == '1'): ?>
											    	<span class="text-black"><?php echo e($data->end_date); ?></span>
											    	<?php else: ?>
											    	<span class="text-black"><?php echo e($data->start_date); ?></span>
											    	<?php endif; ?>
											    </div>
											    <div class="col-6">
											    	<span class="text-grey">End Time</span> <br/>
											    	<span class="text-black"><?php echo e($data->end_time); ?></span>
											    </div>
											</div>

											<div class="row">
											    <div class="col-6">
											    	<span class="text-grey">Deadline</span> <br/>
											    	<span class="text-black"><?php echo e($data->register_end_date); ?> , <?php echo e($data->register_end_time); ?></span>
											    </div>
											    <div class="col-6">
											    	<span class="text-grey">Max Participants</span> <br/>
											    	<span class="text-black"><?php echo e($data->max_participants); ?></span>
											    </div>
											</div>

											<div class="row">
											    <div class="col-12">
											    	<span class="text-grey">Comments</span> <br/>
											    	<span class="text-black"><?php echo e($data->comments??'NA'); ?></span>
											    </div>
											</div>
										  </div>
										</div>
				                  	</div>

				                  	<div class="col-6" style="padding: 10px;">
				                  		<div class="card bg-light mb-3">
										  <div class="card-header">Place</div>
										  <div class="card-body">
										    <div class="row">
											    <div class="col-6">
											    	<span class="text-grey">Place</span> <br/>
											    	<span class="text-black"><?php echo e($data->place); ?></span>
											    </div>
											    <div class="col-6">
											    	<span class="text-grey">Meeting Place</span> <br/>
											    	<span class="text-black"><?php echo e($data->meeting_place); ?></span>
											    </div>
											</div>
											<div class="row">
											    <div class="col-6">
											    	<span class="text-grey">Meeting Time</span> <br/>
											    	<span class="text-black"><?php echo e($data->meeting_time); ?></span>
											    </div>
											    <div class="col-6">
											    	<span class="text-grey">Selection Type</span> <br/>
											    	<span class="text-black"><?php echo e($data->selectionType->name??'NA'); ?></span>
											    </div>
											</div>
										  </div>
										</div>
				                  	</div>

				                  	<div class="col-6" style="padding: 10px;">
				                  		<div class="card bg-light mb-3">
										  <div class="card-header">Registration</div>
										  <div class="card-body">
										    <div class="col-6">
										    	<span class="text-grey">Registered ( 0 )</span> <br/>
										    	<span class="text-black">No Attendees</span>
										    </div>
										     <div class="col-6">
										    	<span class="text-grey">Not attending ( <?php echo e($nonattendeeCount); ?> )</span> <br/>
										    	<span class="text-black">No non-attendees</span>
										    </div>
										     <div class="col-6">
										    	<span class="text-grey">Available ( <?php echo e($attendeeCount); ?> )</span> <br/>
										    	<span class="text-black">No Available</span>
										    </div>
										    <div class="col-6">
										    	<span class="text-grey">Undecided ( 10 )</span> <br/>
										    	<span class="text-black">Test1</span><br/>
										    	<span class="text-black">Test2</span>
										    </div>
										  </div>
										</div>
				                  	</div>

				                  	<div class="col-6" style="padding: 10px;">
				                  		<div class="card bg-light mb-3">
										  <div class="card-header">Driving</div>
										  <div class="card-body">
										    <div class="row">
											    <div class="col-6">
											    	<span class="text-grey">Driving</span> <br/>
											    	<span class="text-black"><?php echo e($data->with_driving == '0' ?'Driving is not activated': $data->with_driving); ?></span>
											    </div>
											</div>
										  </div>
										</div>
				                  	</div>

				                  	<div class="col-6" style="padding: 10px;">
				                  		<div class="card bg-light mb-3">
										  <div class="card-header">Chat</div>
										  <div class="card-body">
										    <p class="card-text">Coming Soon...</p>
										  </div>
										</div>
				                  	</div>
				                  </div>
			                        
								</div>
							</div>
						</div>
					</div>
				
				</div>			
			</div>
			<!-- /Main Wrapper -->
	</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/activities/show.blade.php ENDPATH**/ ?>