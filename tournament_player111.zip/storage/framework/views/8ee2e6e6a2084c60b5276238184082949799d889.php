
<?php $__env->startSection('content'); ?>	

<div class="page-wrapper">
			<div class="content container-fluid">
			
				<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col">
								<h3 class="page-title"><i class="fas fa-user-tie"></i> Members</h3>
								
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						
						<div class="col-lg-12 col-md-12">
							<div class="card">
								<div class="card-body">
									<?php if(Auth::user()->role_id !== 1): ?>
									<h5 style="margin-bottom: 30px ;">Active Team : <b> <?php echo e($team); ?> </b></h5>
									<?php endif; ?>
									<form method="get" action="<?php echo e(route('members.index')); ?>">
										<?php echo csrf_field(); ?>

									<div class="row">
															
				                        <div class="form-group col-3 col-md-3">
			                                <label class="text-white" for="">Region</label>
			                                <select name="region" id="filter_region" class="form-control">
											  <option value="">All Regions</option>
											  <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											  	<option value="<?php echo e($value->id); ?>" <?php echo e($value->id == $region?'selected':''); ?>><?php echo e(strtoupper($value->region_name)); ?></option>
											  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
				                        </div>
				                    <!-- </div>
				                    <div class="row"> -->
									  <div class="form-group col-3 col-md-3">
									  	<label class="text-white" for="">Search</label>
									    <input type="text" name="search" value="<?php echo e($search??''); ?>" class="form-control mr-3" id="" placeholder="search">
										</div>
										<div class="form-group col-1 col-md-1" style="margin-top: 2rem!important;">
									   	<button type="submit" class="btn btn-primary">Search</button>
										</div>

										<div class="form-group col-2 col-md-2" style="margin-top: 2rem!important;">
											<a href="<?php echo e(route('members.index')); ?>">
									   			<button type="button" class="btn btn-danger">Reset Filter</button>
									   		</a>
										</div>
									
									  </div>
									</div>
									</form>
								<div class="row mt-3">
									<div class="col-md-3 offset-md-9">
								  		<a href="<?php echo e(route('member.create')); ?>"><button class="btn btn-success mb-3 float-right">Add Member <i class="fas fa-plus-circle"></i> </button></a>

								  		<!-- <a data-target="#importUsers" data-toggle="modal"><button class="mb-3 btn btn btn-secondary" style="margin-left:10px"><i class="fas fa-file-excel"></i> Import Users</button></a> -->
								  	</div>
								</div>
								  <?php if(session()->has('success')): ?>
									    <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
									<?php endif; ?>

									<?php if(session()->has('error')): ?>
									    <span class="invalid-feedback" role="alert">
				                          <strong><?php echo e($message); ?></strong>
				                      </span>
									<?php endif; ?>
				                  <table id="" class="display table dataTable table-striped table-bordered" >
				                     <thead>
				                        <tr>
				                           <th>#</th>
				                           <th>User Name</th>
				                           <!-- <th>Team</th> -->
				                           <th>Region</th>
				                           <th>Phone</th>
				                           <th>DOB</th>
				                           <th>Street</th>
				                           <th>City</th>
				                           <th>Status</th>
				                           <th>Created At</th>
				                           <th>Action</th>
				                        </tr>
				                     </thead>
				                     <tbody>
				                     	<?php if(count($users) > 0): ?>
				                     	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				                     	<tr>
				                     		<td><?php echo e($users->firstItem() + $key); ?></td>
				                     		<td><?php echo e(ucfirst($user->first_name) ." ". ucfirst($user->last_name)); ?><br /><font style="font-size:10px"><i class="fas fa-envelope"></i>  <?php echo e($user->email); ?></font></td>
				                     		<!-- <td><?php echo e($user->team->team_name??'NA'); ?></td> -->
				                     		<td><?php echo e(strtoupper($user->region->region_name)??'NA'); ?><br /></td>
				                     		<td><?php echo e($user->phone); ?></td>
				                     		<td><?php echo e(date('d M Y', strtotime($user->dob) )); ?></td>
				                     		<td><?php echo e($user->street); ?></td>
				                     		<td><?php echo e($user->city . ", " . $user->getCountry->name??''); ?> <br /><font style="font-size:10px">  #<?php echo e($user->postal_code); ?></font></td>
				                     		<td>
					                        	<?php echo e($user->status==1?'Active':'Inactive'); ?>

					                        </td>
				                     		<td><?php echo e(date('d M Y', strtotime($user->fld_created_at) )); ?></td>
				                     		<td>
					                            <a href="<?php echo e(route('member.edit', $user->id)); ?>" class="btn btn-info" >
					                              <i class="fas fa-edit"></i>
					                            </a>

					                            <a onclick="return confirm('Are you sure you want to delete?');" href="<?php echo e(route('member.destroy', $user->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
				                     		</td>
				                     	</tr>
				                     	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                     	<?php else: ?>
			                                <tr>
			                                    <td colspan="10">No Members Found</td>
			                                </tr>
			                            <?php endif; ?>
			                            </tbody>
			                            <tfoot>
				                           <tr>
				                               <th>#</th>
					                           <th>User Name</th>
					                           <!-- <th>Team</th> -->
					                           <th>Region</th>
					                           <th>Phone</th>
					                           <th>DOB</th>
					                           <th>Street</th>
					                           <th>City</th>
					                           <th>Status</th>
					                           <th>Created At</th>
					                           <th>Action</th>
				                           </tr>
				                        </tfoot>
			                        </table>
			                        
			                        <?php echo e($users->appends(request()->except('page'))->links()); ?>

								</div>
							</div>
						</div>
					</div>
				
				</div>			
			</div>
			<!-- /Main Wrapper -->
	</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pubglite/public_html/test/resources/views/users/index.blade.php ENDPATH**/ ?>