<footer class="mt-5 mb-2" style="text-align:center">
<p style="font-size:14px">Powered by: <b>Tournament Players Pvt. Ltd.</b><br />
© 2022 Tournament Players.</p><br /></footer>


<!-- Bootstrap Core JS -->
<!--<script src="<?php echo e(URL::asset('assets/js/popper.min.js')); ?>"></script>-->
<script src="<?php echo e(URL::asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- Owl JS -->
<!--<script src="<?php echo e(URL::asset('assets/plugins/owlcarousel/owl.carousel.min.js')); ?>"></script>-->
<!-- Datepicker Core JS -->
<script src="<?php echo e(URL::asset('assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>
<!-- Slimscroll JS -->
<script src="<?php echo e(URL::asset('assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- Mask JS -->
<script src="<?php echo e(URL::asset('assets/js/jquery.maskedinput.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/mask.js')); ?>"></script>
<!-- Datatables JS -->
<script src="<?php echo e(URL::asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" integrity="sha512-uto9mlQzrs59VwILcLiRYeLKPPbS/bT71da/OEBYEwcdNUk8jYIy+D176RYoop1Da+f9mvkYrmj5MCLZWEtQuA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- jvectormap JS -->
<!--<script src="<?php echo e(URL::asset('assets/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/jvectormap/jquery-jvectormap-world-mill.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/jvectormap/jquery-jvectormap-ru-mill.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/jvectormap/jquery-jvectormap-us-aea.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/jvectormap/jquery-jvectormap-uk_countries-mill.js')); ?>"></script>        
<script src="<?php echo e(URL::asset('assets/plugins/jvectormap/jquery-jvectormap-in-mill.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/jvectormap.js')); ?>"></script> -->
<!-- Full Calendar JS -->
<!--<script src="<?php echo e(URL::asset('assets/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/fullcalendar/fullcalendar.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/fullcalendar/jquery.fullcalendar.js')); ?>"></script>-->



<!-- Select2 JS -->
<script src="<?php echo e(URL::asset('assets/js/select2.min.js')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(URL::asset('assets/js/admin.js')); ?>"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
      <script id="rendered-js" >
$(document).on("click", '[data-toggle="lightbox"]', function (event) {
  event.preventDefault();
  $(this).ekkoLightbox();
});
//# sourceURL=pen.js
    </script><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/layout/partials/footer-scripts.blade.php ENDPATH**/ ?>