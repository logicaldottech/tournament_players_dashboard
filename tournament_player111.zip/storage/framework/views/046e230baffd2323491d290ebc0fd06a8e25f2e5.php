
<?php $__env->startSection('content'); ?>	

<?php $id ="" ?>
<div class="page-wrapper">
			<div class="content container-fluid">
			
				<!-- Page Header -->
				<div class="page-header">
					<div class="row">
						<div class="col">
							<h3 class="page-title"><i class="<?php echo e($icon); ?>" style="color: #518c68"></i> Teams</h3>
						</div> 
					</div>
				</div>
				<!-- Page Header -->
				        
				<!-- table -->
				<div class="row">
					<div class="col-12">
						<a href="<?php echo e(url("/team/create")); ?>"><button class="mb-3 btn btn-primary float-right" style="margin-left:10px"><i class="fa fa-plus" aria-hidden="true"></i> Add Team</button></a>
						
					<?php if(session()->has('success')): ?>
					    <p class="alert alert-success alert-dismissible fade show"><?php echo e(Session::get('success')); ?></p>
					<?php endif; ?>

					<?php if(session()->has('error')): ?>
					    <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
					<?php endif; ?>

	                  <table id="" class="display table dataTable table-striped table-bordered" >
	                     <thead>
	                        <tr>
		                        <th scope="col">#</th>
		                        <th scope="col">NAME</th>
		                        <th>Region</th>
		                        <th scope="col">STATUS</th>
		                        <th scope="col">ACTION</th>
		                     </tr>
	                     </thead>
	                     <tbody>
	                     	<?php if(count($data) > 0): ?>
	                     	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                  

		                     <tr>
		                        <td><?php echo e($data->firstitem() + $key); ?></td>
		                        <td><?php echo e($value->team_name); ?></td>

		                        <th><?php echo e(ucfirst($value->region->region_name)); ?></th>

			                    <td>
		                        	<?php echo e($value->status===1?'Active':'Inactive'); ?>

		                        </td>
		                        <td>
		                        	
		                        	<a href="<?php echo e(route('team.edit', $value->id)); ?>" class="btn btn-info"><i class="fa fa-edit"></i></a>
		                        	<a onclick="return confirm('Are you sure you want to delete?');" href="<?php echo e(route('team.destroy', $value->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
		                        	
		                        </td>
		                     </tr>
		                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                     	<?php else: ?>
                                <tr>
                                    <td colspan="5">No Teams Found</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                            <tfoot>
	                           <tr>
		                        <th scope="col">#</th>
		                        <th scope="col">NAME</th>
		                        <th>Region</th>
		                        <th scope="col">STATUS</th>
		                        <th scope="col">ACTION</th>
		                     </tr>
	                        </tfoot>
                        </table>
                        
                        <?php echo e($data->appends(request()->except('page'))->links()); ?>

					</div>
				</div>
			</div>
		</div> 
	</div>
	
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('scripts'); ?>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/teams/index.blade.php ENDPATH**/ ?>