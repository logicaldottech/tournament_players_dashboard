<p>Hi <?php echo e($name); ?></p>
<p><?php echo e($content); ?></p>
<p>Thank you !!</p>
<p>
	<i>Tournament Player Team</i>
</p><?php /**PATH /home/pubglite/public_html/test/resources/views/email/template.blade.php ENDPATH**/ ?>