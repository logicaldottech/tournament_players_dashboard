
<?php $__env->startSection('content'); ?>	
<div class="page-wrapper">
			<div class="content container-fluid">
			
				<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col">
								<h3 class="page-title"><?php echo e($title); ?></h3>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						
						<div class="col-lg-12 col-md-12">
							<div class="card">
								<div class="card-body">
									<?php if(session()->has('success')): ?>
									    <div class="alert alert-success alert-dismissible fade show">
									        <?php echo e(session()->get('success')); ?>

									    </div>
									<?php endif; ?>

									<?php if(session()->has('error')): ?>
									    <div class="alert alert-danger alert-dismissible fade show">
									        <?php echo e(session()->get('error')); ?>

									    </div>
									<?php endif; ?>

									<form method="post" action="<?php echo e(isset($data)?route('member.update',$data->id):route('member.store')); ?>">
										
									 <div class="row">
										<?php echo csrf_field(); ?>
										 <div class="form-group col-6">
					                      <label for="">Region</label>
					                      <select name="region" id="" class="form-control">
					                        <option value="">Select Region</option>
					                      <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                        <option value="<?php echo e($value->id); ?>" <?php echo e(isset($data) && $data->region_id==$value->id?'selected':''); ?> ><?php echo e($value->region_name); ?></option>
					                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                      </select>
					                      <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					                        <div class="alert alert-danger"><?php echo e($message); ?></div>
					                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					                    </div>

										   <div class="form-group col-6">
		    								<label for="">Team</label>
										    <select name="team" data-id="0" id="filter_uteams" class="form-control filter_teams">
										    	<option value="">Select Team</option>
										    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										      <option value="<?php echo e($team->id); ?>" <?php echo e(isset($data) && $data->id==$team->id?'selected':''); ?> ><?php echo e($team->team_name); ?></option>
										     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										    </select>
										    <?php $__errorArgs = ['team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		    										<div class="alert alert-danger"><?php echo e($message); ?></div>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
										  </div>

									  <div class="form-group col-6">
									    <label for="">First Name</label>
									    <input type="text" name="first_name" value="<?php echo e($data->first_name??''); ?>" class="form-control" placeholder="First Name">
									    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <div class="form-group col-6">
									    <label for="">Last Name</label>
									    <input type="text" name="last_name" value="<?php echo e($data->last_name??''); ?>" class="form-control" placeholder="Last Name">
									    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <div class="form-group col-6">
									    <label for="">Email Address</label>
									    <input type="text" name="email" placeholder="Email Address" value="<?php echo e($data->email??''); ?>" class="form-control">
									    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <?php if(!isset($data)): ?>
									  <div class="form-group col-6">
									    <label for="">Password</label>
									    <input type="password" name="password" placeholder="Password" class="form-control">
									    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <div class="form-group col-6">
									    <label for=""> Confirm Password</label>
									    <input type="password" name="password_confirmation" placeholder="Confirm Password" class="form-control">
									    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>
									  <?php endif; ?>

									  <div class="form-group col-6">
									    <label for="">Mobile Number</label>
									    <input type="number" name="phone" placeholder="Mobile Number" value="<?php echo e($data->phone??''); ?>" class="form-control">
									    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <div class="form-group col-6">
									    <label for="">Date of Birth</label>
									    <input type="date" name="dob" placeholder="Date of Birth Number" value="<?php echo e($data->dob??''); ?>" class="form-control">
									    <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <div class="form-group col-6">
									    <label for="">City</label>
									    <input type="text" name="city" placeholder="City" value="<?php echo e($data->city??''); ?>" class="form-control">
									    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <div class="form-group col-6">
									    <label for="">Postal Code</label>
									    <input type="number" name="postal_code" placeholder="Postal Code" value="<?php echo e($data->postal_code??''); ?>" class="form-control">
									    <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

									  <div class="form-group col-6">
									    <label for="">Street</label>
									    <input type="text" name="street" placeholder="Street" value="<?php echo e($data->street??''); ?>" class="form-control">
									    <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    										<div class="alert alert-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>

			                        </div>
									  <a href="<?php echo e(route('members.index')); ?>"><button type="button" class="btn btn-danger">Back</button></a>

									  <input type="submit" value="<?php echo e(isset($data)?'Update':'Add'); ?> Member" class="btn btn-<?php echo e(isset($data)?'success':'success'); ?>">
									</form>
								</div>
							</div>
						</div>
					</div>
				
				</div>			
			</div>
			<!-- /Main Wrapper -->
	</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/users/create.blade.php ENDPATH**/ ?>