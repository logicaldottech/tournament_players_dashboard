<!-- Sidebar -->
<div class="sidebar" id="sidebar">
			<div class="sidebar-logo">
				<a href="<?php echo e(route('dashboard')); ?>">
					<img  src="<?php echo e(asset('assets/img/logo/home.png')); ?>" class="img-fluid mb-3" alt="">
				</a>
			</div>
			<div class="sidebar-inner slimscroll">
				<div id="sidebar-menu" class="sidebar-menu">
					<ul>
						<li class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?> <?php echo e(Request::is('dashboard/MH') ? 'active' : ''); ?>">
							<a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a>
						</li>
						
						<li class="<?php echo e(Request::is('teams') ? 'active' : ''); ?>">
							<a href="<?php echo e(route('teams.index')); ?>"><i class="fas fa-users"></i> <span>Teams</span></a>
						</li>
						<li class="<?php echo e(Request::is('members') ? 'active' : ''); ?>">
							<a href="<?php echo e(route('members.index')); ?>"><i class="fas fa-user-tie"></i> <span>Members</span></a>
						</li>

						<li class="<?php echo e(Request::is('activities') ? 'active' : ''); ?>">
							<a href="<?php echo e(route('activities.index')); ?>"><i class="fas fa-calendar"></i> <span>Activities</span></a>
						</li>

						<?php if(Auth::user()->role_id == 1): ?>
						<li class="<?php echo e(Request::is('send-emails') ? 'active' : ''); ?>">
							<a href="<?php echo e(route('email.index')); ?>"><i class="fa fa-envelope" aria-hidden="true"></i> <span>Send Emails</span></a>
						</li>
						<?php endif; ?>
						
						<li class="<?php echo e(Request::is('change-password') ? 'active' : ''); ?>">
							<a href="<?php echo e(route('password.change')); ?>"><i class="fa fa-key" aria-hidden="true"></i> <span>Password</span></a>
						</li>

						<li class="">
							<a href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt" aria-hidden="true"></i> <span>Logout</span></a>
						</li>
						
					</ul>
				</div>
			</div>
		</div>
		<!-- /Sidebar --><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/layout/partials/nav.blade.php ENDPATH**/ ?>