<!-- modal start for add payment -->
<div class="modal" id="changePassword">
   <div class="modal-dialog">
      <div class="modal-content">
         <!-- Modal Header -->
         <div class="modal-header">
            <h4 class="modal-title"> Change Password</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
         </div>
         <!-- Modal body -->
         <div class="modal-body">
            <form method="POST" action="<?php echo e(route('user.password')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(Session::has('success')): ?>
                  <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
                  <?php endif; ?>

                  <input type="hidden" name="user_id" value="" id="user_id">
               <div class="form-group row">
                     <label for="password" class="col-md-4 col-form-label text-md-right">New Password</label>
                   <div class="col-md-6">
                       <input type="password" id="password" placeholder="New Password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" autocomplete="password">
                         <span class="invalid-feedback" id="password_error" role="alert">
                             <strong>Password field is required</strong>
                         </span>
                   </div>
               </div>

               <div class="form-group row">
                   <label for="password" class="col-md-4 col-form-label text-md-right">Password Confirmation</label>
                   <div class="col-md-6">
                       <input type="password" id="cpassword" placeholder="Confirm New Password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" autocomplete="password_confirmation">
                       <span class="invalid-feedback" id="cpassword_error" role="alert">
                             <strong>Confirm Password field is required</strong>
                        </span>
                        <span class="invalid-feedback" id="cpassword_cerror" role="alert">
                             <strong>Password not match</strong>
                        </span>
                         <span class="valid-feedback" id="successMsg" role="alert">
                             <strong>Password changed successfully</strong>
                        </span>
                         <span class="invalid-feedback" id="errorMsg" role="alert">
                             <strong> Some error occured</strong>
                        </span>
                   </div>
               </div>

               <div class="form-group row mb-0">
                   <div class="col-md-8 offset-md-4">
                       <button type="button" class="btn btn-primary submit_password">
                           Change Password
                       </button>
                      
                   </div>
               </div>
           </form>
            </div>
         </div>
      </div>
      <div class="modal-footer"> </div>
   </div>
</div>
<!-- modal end for add payment --><?php /**PATH C:\xampp\htdocs\projects\logical-dottech\tournament_player\resources\views/modals/change_password.blade.php ENDPATH**/ ?>