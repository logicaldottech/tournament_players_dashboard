<meta charset="utf-8')}}">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0')}}">
<title>Welcome to Tournament Player Website</title>
<!-- Favicons -->
<link rel="shortcut icon" href="{{URL::asset('assets/img/logo/favicon.png')}}">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{URL::asset('assets/plugins/bootstrap/css/bootstrap.min.css')}}">
<!-- Datatables CSS -->
<link rel="stylesheet" href="{{URL::asset('assets/plugins/datatables/datatables.min.css')}}">
<!-- Full Calander CSS -->
<!--<link rel="stylesheet" href="{{URL::asset('assets/plugins/fullcalendar/fullcalendar.min.css')}}"> -->
<!-- Fontawesome CSS -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--<link rel="stylesheet" href="{{URL::asset('assets/plugins/fontawesome/css/fontawesome.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('assets/plugins/fontawesome/css/all.min.css')}}"> -->
<!-- Maps Vector -->
<!--<link rel="stylesheet" href="{{URL::asset('assets/plugins/jvectormap/jquery-jvectormap-2.0.3.css')}}"> -->
<!-- Datepicker CSS -->
<link rel="stylesheet" href="{{URL::asset('assets/css/bootstrap-datetimepicker.min.css')}}">
<!-- Animate CSS -->
<!--<link rel="stylesheet" href="{{URL::asset('assets/css/animate.min.css')}}"> -->
<!-- Owl CSS -->
<!--<link rel="stylesheet" href="{{URL::asset('assets/plugins/owlcarousel/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('assets/plugins/owlcarousel/owl.theme.default.min.css')}}">-->
<!-- Select CSS -->
<link rel="stylesheet" href="{{URL::asset('assets/css/select2.min.css')}}">
<!-- Main CSS -->
<link rel="stylesheet" href="{{URL::asset('assets/css/admin.css')}}">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css'>
<!-- jQuery -->
<script src="{{URL::asset('assets/js/jquery-3.5.0.min.js')}}"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.24/themes/smoothness/jquery-ui.css" />
<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css"
/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).on("click", '[data-toggle="lightbox"]', function(event) {
  event.preventDefault();
  $(this).ekkoLightbox();
});
</script>