<p>Hi {{$name}}</p>
<p>{{$content}}</p>
<p>Thank you !!</p>
<p>
	<i>Tournament Player Team</i>
</p>